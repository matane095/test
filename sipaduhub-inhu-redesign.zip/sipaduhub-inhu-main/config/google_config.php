<?php
define('GOOGLE_CLIENT_ID', '571539851099-330dqab0gmsai65emqanq1hmtv0nnkru.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', 'git add .');
?>
